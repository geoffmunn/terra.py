from .proposal import CancelSoftwareUpgradeProposal, SoftwareUpgradeProposal

__all__ = ["SoftwareUpgradeProposal", "CancelSoftwareUpgradeProposal"]
